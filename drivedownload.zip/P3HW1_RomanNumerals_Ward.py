# CTI-110 
# P3HW1 - Roman Numerals 
# Kayla Ward 
# 17 Sept 2018
#

given_number = int(input("Please enter a number between 1 and 10: "))

if given_number == 1:
    print("I")
elif given_number == 2:
    print("II")
elif given_number == 3:
    print("III")
elif given_number == 4:
    print("IV")
elif given_number == 5:
    print("V")
elif given_number == 6:
    print("VI")
elif given_number == 7:
    print("VII")
elif given_number == 8:
    print("VIII")
elif given_number == 9:
    print("IX")
elif given_number == 10:
    print("X")
else:
    print("Given number not within range.")
