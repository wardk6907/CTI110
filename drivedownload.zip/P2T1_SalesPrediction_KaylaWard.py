# Sales Prediction
# 10 Sept 2018
# CTI-110 P2T1 - Sales Prediction
# Kayla Ward
#
# Get the projected total sales.
total_sales = float(input('Enter the projected sales: '))

# Calculate profit as 23 percent of total sales.
profit = total_sales * 0.23

# Display the profit.
print('The profit is $', format(profit, ',.2f'))

