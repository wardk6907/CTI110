# Fahrenheit Celsius Converter
# 10 Sept 2018
# CTI-110 P2HW1 - Celsius Fahrenheit Converter 
# Kayla Ward
#
# Get the celsius temperature that needs to be converted.
celsius = float(input('Enter the celsius temperature: '))

#Calculate fahrenheit using the given formula.
fahrenheit = celsius * 9 / 5 + 32

#Display the temperature in fahrenheit.
print("The temperature is ", fahrenheit, "degrees fahrenheit")
