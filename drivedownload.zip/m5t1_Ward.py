# P4T1a-Shapes
# 26 Sept 2018
# CTI-110 P4T2 - Bug Collector
# Kayla Ward
#

import turtle
turtle.color("green")
turtle.pensize(7)
turtle.shape("turtle")

for i in range(3):
    turtle.forward(90)
    turtle.right(120)

turtle.penup()
turtle.left(90)
turtle.forward(50)
turtle.pendown()
turtle.color("orange")

for i in range(4):
    turtle.forward(90)
    turtle.right(90)
