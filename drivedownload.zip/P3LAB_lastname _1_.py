# I was supposed to put a comment here
# My Last Name

def main():
    # This program takes a number grade and outputs a letter grade.

    # system uses 10-point grading scale
    A_score = 90
    # TO DO: define the rest of the scores

    
    score = input('Enter grade: ')

    if score >= A_score:
    print('Your grade is: A')
    else:
    if score > B_score:
     print('Your grade is: B')
    else:

    else:
    print('Your grade is: F') # TO DO: finish this







# program start
main()
