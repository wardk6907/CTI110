# Python One- Homework Work One
# 5 September 2018
# CTI-110 Tutorial 1 - My First Python Program
# Kayla Ward
#
print('This is  test of IDLE')
