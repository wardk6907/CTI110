# CTI-110
# Kayla Ward
# 26 Sept 2018
# P4T1b
#

import turtle
turtle.shape("turtle")
turtle.color("blue")
turtle.pensize(width=3)
turtle.left(90)
turtle.forward(100)
turtle.backward(50)
turtle.right(45)
turtle.forward(70)
turtle.backward(70)
turtle.right(90)
turtle.forward(70)
turtle.penup()
turtle.left(45)
turtle.forward(150)
turtle.pendown()
turtle.right(65)
turtle.forward(100)
turtle.left(130)
turtle.forward(70)
turtle.right(130)
turtle.forward(70)
turtle.left(130)
turtle.forward(100)
turtle.hideturtle()
